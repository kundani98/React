import React, { Component } from 'react';
import UserForm from './UserForm';

class App extends Component {
  render() {        
    return (
      <div>
        <UserForm />        
                
      </div>
    );
  }
}

export default App;

//import Products from './Products';
