import React, { Component } from 'react';
import Products from './Products';

class App extends Component {
  render() {        
    return (
      <div>
        <Products />        
      </div>
    );
  }
}

export default App;
